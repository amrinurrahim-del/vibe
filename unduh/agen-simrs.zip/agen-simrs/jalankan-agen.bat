@echo off
REM ===========================================================================
REM  Menjalankan AGEN SIMRS di komputer jaringan rumah sakit (Windows).
REM  Klik dua kali berkas ini, atau pasang di Task Scheduler agar otomatis.
REM ===========================================================================
cd /d "%~dp0"

where php >nul 2>nul
if errorlevel 1 (
  echo.
  echo   PHP tidak ditemukan di komputer ini.
  echo   Pasang PHP CLI terlebih dahulu, atau jalankan agen di komputer yang sudah ada PHP.
  echo   Catatan: SIMGOS sendiri berbasis PHP, jadi PHP biasanya sudah tersedia di server SIMGOS.
  echo.
  pause
  exit /b 1
)

echo.
echo   Menjalankan agen SIMRS... (biarkan jendela ini terbuka)
echo   Tekan Ctrl+C untuk berhenti.
echo.
php agen-simrs.php
pause

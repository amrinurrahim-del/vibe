<?php
/*
 * ============================================================================
 *  KONFIGURASI AGEN SIMRS — SALIN berkas ini menjadi `config.php` lalu isi.
 * ============================================================================
 *
 *  Berkas ini berisi kredensial database SIMGOS. Simpan HANYA di komputer
 *  jaringan rumah sakit — jangan diunggah ke internet atau dikirim lewat chat.
 */

return [
    /* ------------------------------------------------------------------
     * 1. Alamat aplikasi antrian apotek (yang ada di internet)
     * ------------------------------------------------------------------ */
    'app_url' => 'https://andidjemma.vibecoder.co.id/antrian-apotek',

    /* Token agen: salin dari aplikasi → Pengaturan → SIMRS / Rekam Medis → Token Agen. */
    'token'   => 'ISI-TOKEN-AGEN-DI-SINI',

    /* ------------------------------------------------------------------
     * 2. Database SIMGOS (hanya diakses dari komputer ini)
     * ------------------------------------------------------------------ */
    'sumber' => 'mysql',        // 'mysql' = baca database SIMGOS · 'contoh' = data contoh (uji coba)
    'mysql'  => [
        'host'     => '127.0.0.1',   // alamat server SIMGOS
        'port'     => 3306,
        'nama'     => 'simgos',      // nama database
        'pengguna' => 'root',        // pengguna database (sebaiknya akun khusus baca-saja)
        'sandi'    => '',
        'charset'  => 'utf8mb4',
    ],

    /* ------------------------------------------------------------------
     * 3. Cara mengambil data pasien dari SIMGOS
     *    Sesuaikan nama tabel & kolom dengan SIMGOS Anda.
     *    Periksa dengan:  SHOW TABLES;   DESCRIBE pasien;
     * ------------------------------------------------------------------ */
    'sql_pasien' => 'SELECT no_rkm_medis, nm_pasien, tgl_lahir, jk FROM pasien WHERE no_rkm_medis = :rm LIMIT 1',

    /* Nama kolom pada hasil query di atas (untuk mengambil nilainya). */
    'kolom' => [
        'nama'          => 'nm_pasien',
        'tgl_lahir'     => 'tgl_lahir',
        'jenis_kelamin' => 'jk',
    ],

    /* ------------------------------------------------------------------
     * 4. Perilaku agen (biasanya tidak perlu diubah)
     * ------------------------------------------------------------------ */
    'selang_detik'   => 3,      // jeda antar pemeriksaan permintaan (detik)
    'batas'          => 10,     // maksimal permintaan yang diambil sekali putaran
    'timeout'        => 20,     // timeout jaringan (detik)
    'verifikasi_ssl' => true,   // ubah ke false HANYA bila server memakai sertifikat sendiri
    'log_file'       => __DIR__ . '/agen-simrs.log',
    'log_maks_kb'    => 1024,   // log dipangkas bila melebihi ukuran ini
];

<?php
declare(strict_types=1);

/*
 * ============================================================================
 *  AGEN SIMRS (SIMGOS) — untuk dijalankan DI JARINGAN RUMAH SAKIT
 * ============================================================================
 *
 *  Fungsi: mengambil permintaan pencarian No. Rekam Medis dari aplikasi antrian
 *  apotek (di internet), membaca data pasien dari database SIMGOS (jaringan RS),
 *  lalu mengirimkan hasilnya kembali. Arah komunikasi selalu dari RS keluar,
 *  sehingga TIDAK perlu membuka port apa pun dari internet ke jaringan RS dan
 *  kredensial database SIMGOS tidak pernah keluar dari komputer ini.
 *
 *  Cara pakai (baris perintah):
 *    php agen-simrs.php             → jalan terus-menerus (layanan)
 *    php agen-simrs.php --sekali    → satu putaran saja (untuk Task Scheduler / cron)
 *    php agen-simrs.php --uji       → periksa koneksi ke aplikasi & database SIMGOS
 *    php agen-simrs.php --rm=123456 → uji cari satu No. RM (tanpa menyentuh permintaan)
 *    php agen-simrs.php --sumber=contoh → pakai data contoh (tanpa database SIMGOS)
 *
 *  Berkas konfigurasi: config.php di folder yang sama (salin dari config.contoh.php).
 */

date_default_timezone_set('Asia/Makassar');

const AGEN_VERSI = '1.0';

/* ------------------------------------------------------------------ */
/* Konfigurasi                                                        */
/* ------------------------------------------------------------------ */

$folder = __DIR__;
$cfgFile = $folder . '/config.php';
if (!is_file($cfgFile)) {
    keluar_galat("Berkas konfigurasi belum ada.\n"
        . "Salin config.contoh.php menjadi config.php, lalu isi alamat aplikasi, token agen, dan kredensial database SIMGOS.");
}
$cfg = require $cfgFile;
if (!is_array($cfg) || !$cfg) {
    keluar_galat('Berkas config.php tidak berisi konfigurasi yang sah.');
}

/** Nilai bawaan konfigurasi. */
$cfg = array_merge([
    'app_url'      => '',                 // contoh: https://domain/antrian-apotek
    'token'        => '',                 // token agen dari Pengaturan → SIMRS
    'selang_detik' => 3,                  // jeda antar pemeriksaan permintaan
    'batas'        => 10,                 // maksimal permintaan per putaran
    'timeout'      => 20,                 // timeout HTTP (detik)
    'verifikasi_ssl' => true,             // false hanya bila server memakai sertifikat sendiri
    'log_file'     => $folder . '/agen-simrs.log',
    'log_maks_kb'  => 1024,               // log dipangkas bila melebihi ukuran ini
    'sumber'       => 'mysql',            // mysql | contoh
    'mysql'        => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'nama'    => 'simgos',
        'pengguna'=> 'root',
        'sandi'   => '',
        'charset' => 'utf8mb4',
    ],
    /* Query pencarian pasien — sesuaikan nama tabel/kolom SIMGOS Anda. */
    'sql_pasien' => 'SELECT no_rkm_medis, nm_pasien, tgl_lahir, jk FROM pasien WHERE no_rkm_medis = :rm LIMIT 1',
    'kolom' => [
        'nama'         => 'nm_pasien',
        'tgl_lahir'    => 'tgl_lahir',
        'jenis_kelamin'=> 'jk',
    ],
], $cfg);

/* ------------------------------------------------------------------ */
/* Utilitas                                                           */
/* ------------------------------------------------------------------ */

function keluar_galat(string $pesan): void
{
    fwrite(STDERR, "GALAT: $pesan\n");
    exit(2);
}

function log_tulis(array $cfg, string $pesan): void
{
    $baris = '[' . date('Y-m-d H:i:s') . '] ' . $pesan . "\n";
    $berkas = (string) $cfg['log_file'];
    /* Pangkas log bila terlalu besar (menjaga ruang disk komputer RS). */
    if (is_file($berkas) && filesize($berkas) > max(64, (int) $cfg['log_maks_kb']) * 1024) {
        $isi = @file_get_contents($berkas);
        if ($isi !== false) {
            @file_put_contents($berkas, substr($isi, -intdiv(strlen($isi), 2)));
        }
    }
    @file_put_contents($berkas, $baris, FILE_APPEND);
    echo $baris;
}

/** Permintaan HTTP sederhana (JSON). */
function http_json(array $cfg, string $url, array $opsi = []): array
{
    $metode = $opsi['metode'] ?? 'GET';
    $badan  = $opsi['badan'] ?? null;

    if (!function_exists('curl_init')) {
        /* Cadangan tanpa curl. */
        $header = "X-Simrs-Token: " . $cfg['token'] . "\r\n";
        $konteksData = ['http' => [
            'method'        => $metode,
            'header'        => $header . ($badan !== null ? "Content-Type: application/json\r\n" : ''),
            'timeout'       => (int) $cfg['timeout'],
            'ignore_errors' => true,
            'content'       => $badan !== null ? $badan : '',
        ]];
        if (!empty($cfg['verifikasi_ssl']) && $cfg['verifikasi_ssl'] === false) {
            $konteksData['ssl'] = ['verify_peer' => false, 'verify_peer_name' => false];
        }
        $isi = @file_get_contents($url, false, stream_context_create($konteksData));
        if ($isi === false) {
            return ['ok' => false, 'error' => 'Tidak dapat menghubungi aplikasi (jaringan/alamat salah).'];
        }
        $json = json_decode((string) $isi, true);
        return is_array($json) ? $json : ['ok' => false, 'error' => 'Jawaban aplikasi tidak dapat dibaca.'];
    }

    $ch = curl_init($url);
    $header = ['X-Simrs-Token: ' . $cfg['token']];
    if ($badan !== null) {
        $header[] = 'Content-Type: application/json';
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $metode,
        CURLOPT_HTTPHEADER     => $header,
        CURLOPT_TIMEOUT        => (int) $cfg['timeout'],
        CURLOPT_SSL_VERIFYPEER => (bool) $cfg['verifikasi_ssl'],
        CURLOPT_SSL_VERIFYHOST => $cfg['verifikasi_ssl'] ? 2 : 0,
    ]);
    if ($badan !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $badan);
    }
    $isi  = curl_exec($ch);
    $kode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($isi === false) {
        return ['ok' => false, 'error' => 'Tidak dapat menghubungi aplikasi: ' . $err];
    }
    $json = json_decode((string) $isi, true);
    if (!is_array($json)) {
        return ['ok' => false, 'error' => 'Jawaban aplikasi tidak dapat dibaca (HTTP ' . $kode . ').'];
    }
    if ($kode === 401) {
        $json['ok'] = false;
        $json['error'] = $json['error'] ?? 'Token agen ditolak. Periksa token di config.php.';
    }
    return $json;
}

/* ------------------------------------------------------------------ */
/* Sumber data pasien                                                 */
/* ------------------------------------------------------------------ */

/**
 * Cari pasien berdasarkan No. RM.
 * Mengembalikan ['ok'=>bool, 'nama'=>..., 'tgl_lahir'=>..., 'jenis_kelamin'=>..., 'pesan'=>...]
 */
function cari_pasien(array $cfg, string $noRm): array
{
    $noRm = trim($noRm);
    if ($noRm === '') {
        return ['ok' => false, 'pesan' => 'Nomor RM kosong.'];
    }

    if (($cfg['sumber'] ?? 'mysql') === 'contoh') {
        /* Sumber contoh: untuk uji coba tanpa database SIMGOS. */
        $nama = 'CONTOH Pasien ' . $noRm;
        return ['ok' => true, 'nama' => $nama, 'tgl_lahir' => '1980-01-01', 'jenis_kelamin' => 'L',
                'pesan' => 'Data contoh (sumber=contoh).'];
    }

    try {
        $m = $cfg['mysql'];
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $m['host'], (int) $m['port'], $m['nama'], $m['charset'] ?: 'utf8mb4');
        $pdo = new PDO($dsn, (string) $m['pengguna'], (string) $m['sandi'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT            => 10,
        ]);
        $st = $pdo->prepare((string) $cfg['sql_pasien']);
        $st->execute(['rm' => $noRm]);
        $baris = $st->fetch();
        if (!$baris) {
            return ['ok' => false, 'pesan' => 'Pasien dengan No. RM ' . $noRm . ' tidak ditemukan di SIMGOS.'];
        }

        $k = $cfg['kolom'];
        $ambil = static function (array $b, string $nama) {
            if ($nama !== '' && array_key_exists($nama, $b)) {
                return trim((string) $b[$nama]);
            }
            /* Bila nama kolom tidak persis sama, coba pencocokan tanpa membedakan huruf besar/kecil. */
            foreach ($b as $kk => $vv) {
                if (strcasecmp((string) $kk, $nama) === 0) {
                    return trim((string) $vv);
                }
            }
            return '';
        };

        return [
            'ok'            => true,
            'nama'          => $ambil($baris, (string) $k['nama']),
            'tgl_lahir'     => $ambil($baris, (string) $k['tgl_lahir']),
            'jenis_kelamin' => $ambil($baris, (string) $k['jenis_kelamin']),
        ];
    } catch (Throwable $e) {
        return ['ok' => false, 'pesan' => 'Gagal membaca database SIMGOS: ' . $e->getMessage()];
    }
}

/* ------------------------------------------------------------------ */
/* Argumen                                                            */
/* ------------------------------------------------------------------ */

$arg = $argv ?? [];
$modeSekali = in_array('--sekali', $arg, true);
$modeUji    = in_array('--uji', $arg, true);
$rmUji      = '';
$sumberArg  = '';
foreach ($arg as $a) {
    if (strpos($a, '--rm=') === 0) { $rmUji = substr($a, 5); }
    if (strpos($a, '--sumber=') === 0) { $sumberArg = substr($a, 9); }
}
if ($sumberArg !== '') {
    $cfg['sumber'] = $sumberArg;
}

if ($cfg['app_url'] === '' || $cfg['token'] === '') {
    keluar_galat("Isi 'app_url' dan 'token' pada config.php terlebih dahulu.\n"
        . "Token agen dapat disalin dari aplikasi: Pengaturan → SIMRS / Rekamedis → Token Agen.");
}
$appUrl = rtrim((string) $cfg['app_url'], '/');

/* ------------------------------------------------------------------ */
/* Mode: uji koneksi                                                  */
/* ------------------------------------------------------------------ */

if ($modeUji) {
    echo "=== UJI AGEN SIMRS (versi " . AGEN_VERSI . ") ===\n\n";

    echo "1) Koneksi ke aplikasi antrian apotek\n";
    echo "   Alamat: $appUrl/simrs.php\n";
    $ping = http_json($cfg, $appUrl . '/simrs.php?action=ping&versi=' . urlencode(AGEN_VERSI));
    if (!empty($ping['ok'])) {
        echo "   BERHASIL — token diterima. Aplikasi: " . ($ping['aplikasi'] ?? '-')
            . " | integrasi SIMRS: " . (!empty($ping['simrs_aktif']) ? 'menyala' : 'BELUM dinyalakan') . "\n";
    } else {
        echo "   GAGAL — " . ($ping['error'] ?? 'tidak diketahui') . "\n";
    }

    echo "\n2) Sumber data pasien\n";
    echo "   Mode sumber: " . $cfg['sumber'] . "\n";
    if ($cfg['sumber'] === 'mysql') {
        $m = $cfg['mysql'];
        echo "   Database: " . $m['pengguna'] . '@' . $m['host'] . ':' . $m['port'] . '/' . $m['nama'] . "\n";
    }
    $rmCoba = $rmUji !== '' ? $rmUji : '1';
    $hasil = cari_pasien($cfg, $rmCoba);
    if (!empty($hasil['ok'])) {
        echo "   BERHASIL — contoh pencarian No. RM $rmCoba → nama: " . ($hasil['nama'] ?: '(kosong)')
            . " | lahir: " . ($hasil['tgl_lahir'] ?: '-') . " | JK: " . ($hasil['jenis_kelamin'] ?: '-') . "\n";
    } else {
        echo "   GAGAL/TIDAK DITEMUKAN — " . ($hasil['pesan'] ?? '') . "\n";
        echo "   Periksa nama tabel & kolom pada config.php ('sql_pasien'), contoh untuk memeriksa:\n";
        echo "     SHOW TABLES;  DESCRIBE pasien;\n";
    }

    echo "\nSelesai. Bila langkah 1 dan 2 BERHASIL, jalankan agen: php agen-simrs.php\n";
    exit(0);
}

if ($rmUji !== '') {
    $hasil = cari_pasien($cfg, $rmUji);
    echo json_encode($hasil, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), "\n";
    exit(!empty($hasil['ok']) ? 0 : 1);
}

/* ------------------------------------------------------------------ */
/* Putaran kerja                                                      */
/* ------------------------------------------------------------------ */

function satu_putaran(array $cfg, string $appUrl, bool $verbose = true): int
{
    $tugas = http_json($cfg, $appUrl . '/simrs.php?action=tugas&batas=' . (int) $cfg['batas']
        . '&versi=' . urlencode(AGEN_VERSI));
    if (empty($tugas['ok'])) {
        if ($verbose) {
            log_tulis($cfg, 'GAGAL mengambil tugas: ' . ($tugas['error'] ?? 'tidak diketahui'));
        }
        return 0;
    }

    $daftar = $tugas['tugas'] ?? [];
    if (!$daftar) {
        return 0;
    }

    $jumlah = 0;
    foreach ($daftar as $t) {
        $id   = (int) ($t['id'] ?? 0);
        $noRm = (string) ($t['no_rm'] ?? '');
        if ($id <= 0) { continue; }

        $hasil = cari_pasien($cfg, $noRm);
        $jawab = [
            'id'            => $id,
            'ok'            => !empty($hasil['ok']),
            'nama'          => (string) ($hasil['nama'] ?? ''),
            'tgl_lahir'     => (string) ($hasil['tgl_lahir'] ?? ''),
            'jenis_kelamin' => (string) ($hasil['jenis_kelamin'] ?? ''),
            'pesan'         => (string) ($hasil['pesan'] ?? ''),
        ];
        $kirim = http_json($cfg, $appUrl . '/simrs.php?action=jawab&versi=' . urlencode(AGEN_VERSI), [
            'metode' => 'POST',
            'badan'  => json_encode($jawab, JSON_UNESCAPED_UNICODE),
        ]);
        if (!empty($kirim['ok'])) {
            $jumlah++;
            log_tulis($cfg, 'Permintaan #' . $id . ' (RM ' . $noRm . ') dijawab: '
                . ($jawab['ok'] ? ('nama "' . $jawab['nama'] . '"') : ('tidak ditemukan — ' . $jawab['pesan'])));
        } else {
            log_tulis($cfg, 'GAGAL mengirim jawaban #' . $id . ': ' . ($kirim['error'] ?? 'tidak diketahui'));
        }
    }
    return $jumlah;
}

log_tulis($cfg, 'Agen SIMRS versi ' . AGEN_VERSI . ' dijalankan (sumber data: ' . $cfg['sumber']
    . ', selang ' . (int) $cfg['selang_detik'] . ' detik). Tekan Ctrl+C untuk berhenti.');

if ($modeSekali) {
    $n = satu_putaran($cfg, $appUrl);
    log_tulis($cfg, 'Putaran tunggal selesai — ' . $n . ' permintaan dijawab.');
    exit(0);
}

/* Mode layanan: berjalan terus, dengan jeda & pengaman bila aplikasi tidak dapat dihubungi. */
$gagalBerturut = 0;
while (true) {
    $n = satu_putaran($cfg, $appUrl, true);
    if ($n === 0) {
        $gagalBerturut++;
    } else {
        $gagalBerturut = 0;
    }
    /* Bila berkali-kali gagal, beri jeda lebih panjang agar tidak membanjiri jaringan. */
    $jeda = (int) $cfg['selang_detik'];
    if ($gagalBerturut >= 3) {
        $jeda = max($jeda, min(60, $jeda * $gagalBerturut));
    }
    sleep(max(1, $jeda));
}

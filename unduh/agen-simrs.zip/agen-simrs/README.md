# Agen SIMRS (SIMGOS) — Panduan Pemasangan

Agen ini menghubungkan aplikasi **Antrian Apotek** dengan **database SIMGOS** yang hanya bisa
diakses dari **jaringan rumah sakit**.

```
[PC apotek / browser petugas] ──┐
                                │  (internet)
                                ▼
                    [Aplikasi Antrian Apotek]
                                ▲
                                │  HTTPS keluar dari jaringan RS
                                │  (tidak ada port yang dibuka ke internet)
                    [AGEN SIMRS] ──► [database SIMGOS]
                     (di komputer jaringan RS)
```

Alur kerjanya:

1. Petugas mengetik **No. Rekam Medis** di form Ambil Antrian, lalu menekan **Cari Pasien**.
2. Aplikasi mencatat permintaan (status *menunggu*).
3. **Agen** di jaringan RS mengambil permintaan itu, membaca data pasien dari database SIMGOS,
   lalu mengirim jawabannya ke aplikasi.
4. Nama pasien muncul di layar petugas dan ikut tercetak di tiket.

Kalau agen mati atau RM tidak ditemukan, petugas **tetap dapat mengisi nama manual** dan mengambil
tiket — antrean tidak pernah macet karena masalah server.

---

## 1. Yang dibutuhkan

| Kebutuhan | Keterangan |
| --- | --- |
| Komputer jaringan RS | Yang bisa mengakses server SIMGOS (boleh komputer yang sama dengan server SIMGOS) |
| PHP CLI | Minimal PHP 7.4 (dengan ekstensi `pdo_mysql`). SIMGOS sendiri berbasis PHP, jadi PHP biasanya sudah ada di server SIMGOS |
| Akun database | Sebaiknya akun **baca-saja (read-only)** khusus untuk agen |
| Token agen | Disalin dari aplikasi: **Pengaturan → SIMRS / Rekamedis → Token Agen** |

> Agen **tidak** membuka port apa pun. Hubungan selalu dari komputer RS ke aplikasi (keluar).

---

## 2. Pemasangan (5 langkah)

1. Salin folder `agen-simrs` ke komputer jaringan RS (mis. `C:\agen-simrs`).
2. Salin `config.contoh.php` menjadi **`config.php`**.
3. Isi `config.php`:
   - `app_url` — alamat aplikasi antrian apotek
   - `token` — token agen dari Pengaturan aplikasi
   - `mysql` — host/port/nama database/pengguna/sandi database SIMGOS
4. **Uji** dulu:
   ```
   php agen-simrs.php --uji
   ```
   Berkas ini akan memeriksa koneksi ke aplikasi **dan** contoh pencarian pasien dari SIMGOS.
5. Jalankan agen:
   ```
   php agen-simrs.php
   ```
   Di Windows bisa cukup klik dua kali **`jalankan-agen.bat`**.

Setelah beberapa detik, di aplikasi akan tampil **Agen terhubung** pada
**Pengaturan → SIMRS / Rekamedis**.

---

## 3. Menyesuaikan nama tabel & kolom SIMGOS

Setiap instalasi SIMGOS bisa berbeda. Periksa struktur tabelnya:

```sql
SHOW TABLES;
DESCRIBE pasien;
```

Contoh yang umum dipakai (dan menjadi bawaan di `config.php`):

| Kolom | Keterangan |
| --- | --- |
| `no_rkm_medis` | nomor rekam medis |
| `nm_pasien` | nama pasien |
| `tgl_lahir` | tanggal lahir |
| `jk` | jenis kelamin |

Bila di SIMGOS Anda namanya berbeda, ubah dua bagian berikut di `config.php`:

```php
'sql_pasien' => 'SELECT no_rkm_medis, nm_pasien, tgl_lahir, jk FROM pasien WHERE no_rkm_medis = :rm LIMIT 1',
'kolom' => [
    'nama'          => 'nm_pasien',
    'tgl_lahir'     => 'tgl_lahir',
    'jenis_kelamin' => 'jk',
],
```

Catatan: nama kolom `:rm` pada query **jangan diubah** — itu penanda yang diisi otomatis.

Bila tabel pasien menyimpan nama dalam huruf besar semua, hasilnya akan tampil apa adanya;
bisa dirapikan belakangan bila diinginkan.

---

## 4. Perintah yang tersedia

| Perintah | Fungsi |
| --- | --- |
| `php agen-simrs.php` | Menjalankan agen terus-menerus (biarkan jendela terbuka) |
| `php agen-simrs.php --sekali` | Satu putaran saja (cocok untuk Task Scheduler / cron tiap menit) |
| `php agen-simrs.php --uji` | Memeriksa koneksi ke aplikasi dan ke database SIMGOS |
| `php agen-simrs.php --rm=123456` | Mencoba cari satu No. RM langsung (tanpa menyentuh permintaan aplikasi) |
| `php agen-simrs.php --sumber=contoh` | Menjalankan agen tanpa database (data contoh, untuk uji coba) |

### Menjalankan otomatis (Windows Task Scheduler)

1. Buka **Task Scheduler** → **Create Task**.
2. **Triggers** → New → *Daily*, atau *At startup*.
3. **Actions** → New → Program: `php.exe`, Arguments: `agen-simrs.php --sekali`,
   *Start in*: `C:\agen-simrs`.
4. **Repeat task every**: 1 minute (pada tab Triggers).

Cara ini membuat agen berjalan singkat tiap menit tanpa perlu jendela yang terus terbuka.

---

## 5. Bila ada masalah

| Gejala | Kemungkinan & penanganan |
| --- | --- |
| `Token agen ditolak` | Token di `config.php` berbeda dengan di Pengaturan aplikasi. Salin ulang tokennya. |
| `Tidak dapat menghubungi aplikasi` | Komputer RS tidak punya akses internet, atau `app_url` salah (periksa alamatnya di browser). |
| `Gagal membaca database SIMGOS` | Host/nama database/pengguna/sandi salah, atau akun tidak punya izin membaca tabel pasien. |
| Pencarian selalu "tidak ditemukan" | Nama tabel/kolom belum sesuai — lihat bagian 3 di atas. |
| Di aplikasi tampil "Agen belum terhubung" | Agen tidak berjalan atau jaringan RS sedang putus. Jalankan `--uji` untuk memeriksa. |
| Pencarian lama sekali | Agen berjalan dengan `selang_detik` besar. Turunkan nilainya (bawaan 3 detik). |

Log agen tersimpan di **`agen-simrs.log`** (dipangkas otomatis bila terlalu besar).

---

## 6. Catatan privasi & keamanan

- Nama pasien **hanya** dikirim untuk tiket yang sedang dibuat, lalu disimpan bersama tiket itu di
  aplikasi. Data ini **tidak** ditampilkan di layar display (TV ruang tunggu) maupun di halaman lacak QR.
- Kredensial database SIMGOS hanya berada di berkas `config.php` di komputer rumah sakit — tidak pernah
  dikirim ke aplikasi atau disimpan di server internet.
- Aplikasi hanya menyimpan **permintaan & jawaban pencarian**; riwayat lamanya dapat dibersihkan dari
  Pengaturan → SIMRS / Rekamedis → **Bersihkan Riwayat Pencarian**.
- Gunakan akun database **baca-saja** untuk agen, bukan akun administrator SIMGOS.

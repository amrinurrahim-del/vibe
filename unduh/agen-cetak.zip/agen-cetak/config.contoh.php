<?php
/*
 * ============================================================================
 *  KONFIGURASI AGEN CETAK — SALIN berkas ini menjadi `config.php` lalu isi.
 *  PENTING: setiap baris di dalam [ ... ] WAJIB diakhiri tanda koma ( , ).
 *  Koma yang hilang membuat PHP menolak berkas ini ("PHP Parse error ...
 *  expecting ]"), agen tidak pernah hidup, dan aplikasi hanya berkata
 *  "tidak dapat menghubungi agen". Isi hanya bagian yang bertanda ISI-...,
 *  jangan mengubah tanda koma/tanda kutip lainnya.
 * ============================================================================
 */

return [
    /* ------------------------------------------------------------------
     * 1. Nama printer THERMAL yang dipakai aplikasi antrian apotek.
     *    Tulis PERSIS seperti nama printer di Windows (lihat Pengaturan
     *    Windows → Printer & scanner, atau tekan "Ambil daftar printer"
     *    di aplikasi). Contoh: "EPSON TM-T82 Receipt", "POS-80C".
     *    Printer default Windows TIDAK diubah — aplikasi ini memakai printer
     *    ini, aplikasi lain tetap memakai printer default sistem.
     * ------------------------------------------------------------------ */
    'printer' => 'ISI-NAMA-PRINTER-THERMAL-DI-SINI',

    /* Token dari aplikasi: Pengaturan → Printer → Agen Cetak → Token.
       Mencegah situs lain ikut mencetak lewat agen ini. */
    'token'   => 'ISI-TOKEN-DARI-APLIKASI',

    /* ------------------------------------------------------------------
     * 2. Mode cetak (biasanya tidak perlu diubah)
     *    gambar : aplikasi mengirim gambar tiket (ada QR) → dicetak via PrintTo
     *    teks   : hanya teks polos (tanpa QR) → paling kompatibel di semua driver
     * Coba 'gambar' dulu; bila hasilnya tidak rapi, ganti ke 'teks'.
     * ------------------------------------------------------------------ */
    'mode'    => 'gambar',

    /* ------------------------------------------------------------------
     * 3. Uji coba tanpa printer: true = tiket hanya disimpan sebagai berkas
     *    (di folder keluaran) supaya bisa diperiksa dulu. Ubah ke false
     *    setelah semuanya benar.
     * ------------------------------------------------------------------ */
    'kering'  => false,

    /* Arsip berkas tiket yang dicetak (juga dipakai saat mode uji). */
    'folder_keluar' => __DIR__ . '/keluaran',
    'log_file'      => __DIR__ . '/agen-cetak.log',

    /* Lebar kolom untuk mode teks: 42 untuk kertas 80 mm, 32 untuk 58 mm. */
    'lebar_teks'    => 42,
];

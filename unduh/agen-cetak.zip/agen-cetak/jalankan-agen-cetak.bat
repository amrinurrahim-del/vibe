@echo off
REM ===========================================================================
REM  Menjalankan AGEN CETAK TIKET di komputer apotek (Windows).
REM  Biarkan jendela ini terbuka. Agen hidup di http://127.0.0.1:17890
REM ===========================================================================
cd /d "%~dp0"

where php >nul 2>nul
if errorlevel 1 (
  echo.
  echo   PHP tidak ditemukan di komputer ini.
  echo   Pasang PHP CLI lebih dahulu ^(https://windows.php.net/download^), lalu jalankan lagi.
  echo.
  pause
  exit /b 1
)

if not exist config.php (
  echo.
  echo   config.php belum ada.
  echo   Salin config.contoh.php menjadi config.php, lalu isi nama printer ^& token.
  echo.
  pause
  exit /b 1
)

REM --- Periksa dulu tulisan config.php; salah ketik di sini membuat agen TIDAK PERNAH hidup
REM     (aplikasi hanya akan berkata "tidak dapat menghubungi agen" tanpa tahu sebabnya).
echo   Memeriksa tulisan config.php ...
php -d display_errors=1 -l config.php
if errorlevel 1 goto :config_salah

echo.
echo   Agen cetak tiket hidup di http://127.0.0.1:17890
echo   Tekan Ctrl+C untuk berhenti.
echo.
php -S 127.0.0.1:17890 agen-cetak.php
pause
exit /b 0

:config_salah
echo.
echo   ============================================================
echo    config.php ADA SALAH KETIK - PHP tidak dapat membacanya
echo   ============================================================
echo.
echo   Pesan kesalahan di atas (mis. "unexpected ... expecting ]")
echo   hampir selalu berarti KURANG TANDA KOMA di akhir baris sebelumnya.
echo   Setiap baris di dalam [ ... ] harus diakhiri dengan koma:
echo.
echo       'kering'        =^> false,
echo       'folder_keluar' =^> __DIR__ . '/keluaran',
echo.
echo   Perhatikan tanda koma setelah kata false di atas.
echo.
echo   Cara paling aman: salin ulang config.contoh.php menjadi
echo   config.php, lalu isi HANYA dua baris:
echo       'printer' =^> 'nama printer thermal'
echo       'token'   =^> 'token dari aplikasi'
echo   Jangan mengubah tanda koma, tanda kutip, atau tanda kurung lain.
echo.
echo   Membuka config.php dengan Notepad supaya bisa diperbaiki ...
start "" notepad "config.php"
echo.
echo   Setelah diperbaiki: simpan berkas (Ctrl+S), tutup Notepad,
echo   lalu jalankan lagi jalankan-agen-cetak.bat.
echo.
pause
exit /b 1

<?php
declare(strict_types=1);

/*
 * ============================================================================
 *  AGEN CETAK TIKET — dijalankan di KOMPUTER APOTEK (Windows)
 * ============================================================================
 *
 *  Menjawab masalah: browser TIDAK BISA memilih printer sendiri (demi keamanan),
 *  sehingga aplikasi antrian tidak bisa "mengunci" printer thermal tanpa dialog.
 *  Agen kecil ini menjadi perantara: aplikasi mengirim gambar tiket ke agen, lalu
 *  agen mencetaknya ke PRINTER TERTENTU (nama printer di config.php) — tanpa dialog
 *  dan tanpa mengubah printer default Windows. Aplikasi lain di komputer yang sama
 *  tetap memakai printer default sistem (mis. A4).
 *
 *  Cara jalan:
 *    jalankan-agen-cetak.bat      → agen hidup di http://127.0.0.1:17890
 *    php -S 127.0.0.1:17890 agen-cetak.php   (manual)
 *
 *  Endpoint:
 *    GET  /status  → daftar printer Windows + pengaturan agen
 *    POST /cetak   → cetak satu tiket (body JSON: token, gambar/base64, teks, nama)
 *    GET  /uji     → cetak halaman uji kecil ke printer terpilih
 *
 *  Berkas konfigurasi: config.php (salin dari config.contoh.php).
 */

const AGEN_CETAK_VERSI = '1.1';

/*
 * Membaca config.php dengan AMAN.
 * Bila config.php salah ketik (paling sering: koma yang hilang), PHP melempar ParseError.
 * Dulu hal itu membuat agen tampak "mati" — aplikasi hanya bisa berkata "tidak dapat
 * menghubungi agen", padahal penyebabnya ada di berkas config. Sekarang kesalahan tersebut
 * ditangkap dan dilaporkan apa adanya beserta petunjuk perbaikannya.
 */
$cfgFile  = __DIR__ . '/config.php';
$cfgAda   = is_file($cfgFile);
$cfgGalat = '';
$cfgBaris = 0;
$cfg = [];
if ($cfgAda) {
    try {
        $muat = require $cfgFile;
        if (is_array($muat)) {
            $cfg = $muat;
        } elseif ($muat === 1) {
            $cfgGalat = 'config.php tidak mengembalikan pengaturan — berkas itu harus diakhiri "return [ ... ];".';
        } else {
            $cfgGalat = 'isi config.php harus berupa array PHP ("return [ ... ];").';
        }
    } catch (\ParseError $e) {
        /* ParseError tidak memuat "on line ..." di dalam pesannya — ambil dari objeknya. */
        $cfgGalat = $e->getMessage();
        $cfgBaris = (int) $e->getLine();
    } catch (\Throwable $e) {
        $cfgGalat = 'config.php gagal dibaca: ' . $e->getMessage();
    }
}
$cfg = array_merge([
    'printer'       => '',                       /* nama printer thermal di Windows, mis. "EPSON TM-T82" */
    'token'         => '',                       /* token dari aplikasi (Pengaturan → Printer → Agen Cetak) */
    'mode'          => 'gambar',                 /* gambar | teks */
    'kering'        => false,                    /* true = tidak mencetak, hanya menulis berkas (uji) */
    'folder_keluar' => __DIR__ . '/keluaran',    /* tempat berkas saat mode kering / arsip */
    'log_file'      => __DIR__ . '/agen-cetak.log',
    'lebar_teks'    => 42,                       /* kolom untuk mode teks (42 = 80mm) */
], $cfg);

$windows = (PHP_OS_FAMILY === 'Windows');
$metode  = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$jalur   = parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';

/* ------------------------------------------------------------------ */
/* Utilitas                                                           */
/* ------------------------------------------------------------------ */

function jawab(array $data, int $kode = 200): void
{
    http_response_code($kode);
    header('Content-Type: application/json; charset=utf-8');
    /* CORS: halaman aplikasi (HTTPS) memanggil agen di 127.0.0.1 — respons harus boleh dibaca. */
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function log_tulis(string $pesan): void
{
    global $cfg;
    $berkas = (string) $cfg['log_file'];
    if (is_file($berkas) && filesize($berkas) > 512 * 1024) {
        @file_put_contents($berkas, '');
    }
    @file_put_contents($berkas, '[' . date('Y-m-d H:i:s') . '] ' . $pesan . "\n", FILE_APPEND);
}

/** Escape untuk string di dalam perintah PowerShell (kutip tunggal). */
function ps_teks(string $s): string
{
    return "'" . str_replace("'", "''", $s) . "'";
}

/** Jalankan perintah PowerShell; mengembalikan keluaran. */
function ps_jalan(string $perintah): array
{
    if (PHP_OS_FAMILY !== 'Windows') {
        return ['ok' => false, 'keluar' => '', 'pesan' => 'Bukan Windows — perintah cetak tidak dijalankan.'];
    }
    $penuh = 'powershell -NoProfile -NonInteractive -Command ' . escapeshellarg($perintah) . ' 2>&1';
    $keluar = [];
    $kode = 0;
    @exec($penuh, $keluar, $kode);
    return ['ok' => $kode === 0, 'keluar' => trim(implode("\n", $keluar)), 'pesan' => $kode === 0 ? '' : 'perintah gagal (kode ' . $kode . ')'];
}

/** Daftar nama printer yang terpasang di komputer ini. */
function daftar_printer(): array
{
    if (PHP_OS_FAMILY !== 'Windows') {
        return [];
    }
    $hasil = ps_jalan('Get-Printer | Select-Object -ExpandProperty Name');
    if (!$hasil['ok'] || $hasil['keluar'] === '') {
        return [];
    }
    return array_values(array_filter(array_map('trim', explode("\n", $hasil['keluar']))));
}

/** Petunjuk perbaikan config.php berdasarkan pesan kesalahan PHP. */
function cfg_petunjuk(string $pesan, int $baris): string
{
    $t = [];
    if (strpos($pesan, 'expecting "]"') !== false || strpos($pesan, 'expecting "["') !== false) {
        $t[] = 'Penyebab paling sering: KURANG TANDA KOMA ( , ) di akhir baris ' . max(1, $baris - 1) . '.';
        $t[] = 'Setiap baris di dalam [ ... ] harus diakhiri koma — contoh yang benar:';
        $t[] = "";
        $t[] = "    'kering'        => false,";
        $t[] = "    'folder_keluar' => __DIR__ . '/keluaran',";
        $t[] = "";
        $t[] = 'Perhatikan tanda koma di akhir baris "false," di atas.';
    } elseif (strpos($pesan, 'unexpected end of file') !== false) {
        $t[] = 'Penyebab paling sering: tanda penutup kurung siku "];" atau tanda kutip yang belum ditutup.';
    } elseif (strpos($pesan, 'Unclosed') !== false || strpos($pesan, 'unterminated') !== false) {
        $t[] = 'Ada tanda kutip ( \' atau " ) yang belum ditutup.';
    } else {
        $t[] = 'Periksa tanda koma, tanda kutip, dan tanda kurung di sekitar baris ' . $baris . '.';
    }
    $t[] = '';
    $t[] = 'Cara cepat: salin ulang config.contoh.php menjadi config.php, lalu isi hanya '
         . 'dua baris (nama printer & token) — jangan mengubah tanda koma/tanda kutip lainnya.';
    return implode("\n", $t);
}

/* ------------------------------------------------------------------ */
/* config.php bermasalah → jelaskan, jangan biarkan pemilik menebak    */
/* ------------------------------------------------------------------ */
if (!$cfgAda || $cfgGalat !== '') {
    $pesan = !$cfgAda
        ? "Berkas config.php BELUM ADA di folder agen ini.\n"
          . "Salin config.contoh.php menjadi config.php, lalu isi nama printer + token dari aplikasi."
        : "config.php BERMASALAH sehingga agen tidak dapat mencetak.\n\n"
          . $cfgGalat . ($cfgBaris > 0 ? ' (baris ' . $cfgBaris . ')' : '') . "\n\n"
          . cfg_petunjuk($cfgGalat, $cfgBaris);
    log_tulis('CONFIG bermasalah: ' . str_replace("\n", ' | ', $pesan));
    jawab([
        'ok'           => false,
        'versi'        => AGEN_CETAK_VERSI,
        'config_error' => true,
        'berkas'       => $cfgFile,
        'baris'        => $cfgBaris,
        'pesan'        => $pesan,
    ], 400);
}

/* ------------------------------------------------------------------ */
/* OPTIONS (pra-permintaan CORS)                                      */
/* ------------------------------------------------------------------ */
if ($metode === 'OPTIONS') {
    jawab(['ok' => true]);
}

/* ------------------------------------------------------------------ */
/* GET /status                                                        */
/* ------------------------------------------------------------------ */
if ($jalur === '/status' || $jalur === '/' || $jalur === '/index.php') {
    $daftar = daftar_printer();
    $printer = (string) $cfg['printer'];
    jawab([
        'ok'          => true,
        'versi'       => AGEN_CETAK_VERSI,
        'platform'    => PHP_OS_FAMILY,
        'windows'     => $windows,
        'printer'     => $printer,
        'mode'        => (string) $cfg['mode'],
        'kering'      => (bool) $cfg['kering'],
        'daftar_printer' => $daftar,
        'printer_terpasang' => $printer !== '' && in_array($printer, $daftar, true),
        'catatan'     => $windows
            ? ($printer === '' ? 'Nama printer belum diisi di config.php.' : '')
            : 'Agen ini berjalan di luar Windows — pengujian hanya dapat memakai mode kering.',
    ]);
}

/* ------------------------------------------------------------------ */
/* GET /uji → cetak halaman uji                                       */
/* ------------------------------------------------------------------ */
if ($jalur === '/uji') {
    $printer = (string) $cfg['printer'];
    if ($printer === '') {
        jawab(['ok' => false, 'pesan' => 'Nama printer belum diisi di config.php agen.'], 400);
    }
    $isi = "AGEN CETAK TIKET — UJI COBA\n"
        . "Waktu: " . date('d/m/Y H:i:s') . "\n"
        . "Printer tujuan: " . $printer . "\n"
        . "Bila kertas ini keluar dari printer thermal, berarti agen sudah benar.\n";
    $berkas = rtrim((string) $cfg['folder_keluar'], '/\\') . '/uji-cetak-' . date('Ymd-His') . '.txt';
    if (!is_dir(dirname($berkas))) { @mkdir(dirname($berkas), 0775, true); }
    @file_put_contents($berkas, $isi);

    if ($cfg['kering'] || !$windows) {
        log_tulis('UJI (mode kering): berkas ' . $berkas);
        jawab(['ok' => true, 'kering' => true, 'berkas' => $berkas,
               'pesan' => 'Mode kering: halaman uji ditulis ke ' . $berkas . ' (tidak dikirim ke printer).']);
    }
    $hasil = ps_jalan('Get-Content -Raw -LiteralPath ' . ps_teks($berkas) . ' | Out-Printer -Name ' . ps_teks($printer));
    log_tulis('UJI: printer=' . $printer . ' ok=' . ($hasil['ok'] ? '1' : '0') . ' ' . $hasil['keluar']);
    jawab([
        'ok'      => $hasil['ok'],
        'pesan'   => $hasil['ok'] ? 'Halaman uji dikirim ke printer "' . $printer . '".' : 'Gagal mengirim ke printer: ' . $hasil['keluar'],
    ], $hasil['ok'] ? 200 : 500);
}

/* ------------------------------------------------------------------ */
/* POST /cetak                                                        */
/* ------------------------------------------------------------------ */
if ($jalur === '/cetak') {
    if ($metode !== 'POST') {
        jawab(['ok' => false, 'pesan' => 'Gunakan POST.'], 405);
    }
    $mentah = (string) file_get_contents('php://input');
    $data = json_decode($mentah, true);
    if (!is_array($data)) {
        jawab(['ok' => false, 'pesan' => 'Badan permintaan harus JSON.'], 400);
    }
    /* Token (bila diisi) mencegah situs lain mencetak lewat agen di komputer ini. */
    $tokenAgen = (string) $cfg['token'];
    if ($tokenAgen !== '' && !hash_equals($tokenAgen, (string) ($data['token'] ?? ''))) {
        log_tulis('TOLAK: token tidak cocok');
        jawab(['ok' => false, 'pesan' => 'Token tidak cocok. Samakan token di config.php agen dengan Pengaturan aplikasi.'], 401);
    }
    $printer = (string) $cfg['printer'];
    if ($printer === '') {
        jawab(['ok' => false, 'pesan' => 'Nama printer belum diisi di config.php agen.'], 400);
    }

    $gambar = (string) ($data['gambar'] ?? '');     /* PNG base64 */
    $teks   = (string) ($data['teks'] ?? '');
    $nama   = preg_replace('/[^A-Za-z0-9._-]/', '', (string) ($data['nama'] ?? 'tiket')) ?: 'tiket';
    $folder = rtrim((string) $cfg['folder_keluar'], '/\\');
    if (!is_dir($folder)) { @mkdir($folder, 0775, true); }

    $mode = (string) $cfg['mode'];
    if ($mode === 'gambar' && $gambar === '') {
        /* Tidak ada gambar (mis. gagal dibuat di server aplikasi) → pakai mode teks. */
        $mode = 'teks';
    }
    if ($mode === 'teks' && $teks === '') {
        jawab(['ok' => false, 'pesan' => 'Isi tiket kosong (tidak ada gambar maupun teks).'], 400);
    }

    if ($mode === 'gambar') {
        $bytes = base64_decode($gambar, true);
        if ($bytes === false || strlen($bytes) < 100) {
            jawab(['ok' => false, 'pesan' => 'Data gambar tiket tidak sah.'], 400);
        }
        $berkas = $folder . '/' . $nama . '-' . date('Ymd-His') . '.png';
        if (@file_put_contents($berkas, $bytes) === false) {
            jawab(['ok' => false, 'pesan' => 'Gagal menulis berkas tiket di komputer ini.'], 500);
        }
        if ($cfg['kering'] || !$windows) {
            log_tulis('CETAK (mode kering): ' . $berkas);
            jawab(['ok' => true, 'kering' => true, 'berkas' => $berkas, 'printer' => $printer,
                   'pesan' => 'Mode kering: tiket disimpan sebagai ' . $berkas . ' (tidak dikirim ke printer).']);
        }
        /* PrintTo memakai aplikasi gambar bawaan Windows; printer ditentukan langsung. */
        $hasil = ps_jalan('Start-Process -FilePath ' . ps_teks($berkas) . ' -Verb PrintTo -ArgumentList ' . ps_teks($printer));
        log_tulis('CETAK gambar: printer=' . $printer . ' berkas=' . $berkas . ' ok=' . ($hasil['ok'] ? '1' : '0') . ' ' . $hasil['keluar']);
        jawab([
            'ok'      => $hasil['ok'],
            'printer' => $printer,
            'berkas'  => $berkas,
            'pesan'   => $hasil['ok']
                ? 'Tiket dikirim ke printer "' . $printer . '".'
                : 'Gagal mengirim ke printer: ' . $hasil['keluar'],
        ], $hasil['ok'] ? 200 : 500);
    }

    /* Mode teks: cetak teks polos lewat spooler (paling kompatibel). */
    $berkas = $folder . '/' . $nama . '-' . date('Ymd-His') . '.txt';
    if (@file_put_contents($berkas, $teks) === false) {
        jawab(['ok' => false, 'pesan' => 'Gagal menulis berkas tiket di komputer ini.'], 500);
    }
    if ($cfg['kering'] || !$windows) {
        log_tulis('CETAK teks (mode kering): ' . $berkas);
        jawab(['ok' => true, 'kering' => true, 'berkas' => $berkas, 'printer' => $printer,
               'pesan' => 'Mode kering: tiket disimpan sebagai ' . $berkas . ' (tidak dikirim ke printer).']);
    }
    $hasil = ps_jalan('Get-Content -Raw -LiteralPath ' . ps_teks($berkas) . ' | Out-Printer -Name ' . ps_teks($printer));
    log_tulis('CETAK teks: printer=' . $printer . ' ok=' . ($hasil['ok'] ? '1' : '0') . ' ' . $hasil['keluar']);
    jawab([
        'ok'      => $hasil['ok'],
        'printer' => $printer,
        'berkas'  => $berkas,
        'pesan'   => $hasil['ok']
            ? 'Tiket dikirim ke printer "' . $printer . '".'
            : 'Gagal mengirim ke printer: ' . $hasil['keluar'],
    ], $hasil['ok'] ? 200 : 500);
}

/* ------------------------------------------------------------------ */
jawab(['ok' => false, 'pesan' => 'Alamat tidak dikenal: ' . $jalur], 404);

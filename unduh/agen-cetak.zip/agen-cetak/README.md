# Agen Cetak Tiket — Panduan Pemasangan

Agen ini membuat aplikasi antrian apotek bisa mencetak tiket **langsung ke printer thermal tertentu
tanpa dialog cetak**, tanpa mengubah printer default Windows.

```
[Komputer apotek]
   Browser aplikasi antrian  ──►  [AGEN CETAK]  ──►  Printer Thermal (ditentukan)
   Aplikasi lain (A4)        ──►  Sistem Windows ──►  Printer default (A4)
```

## Kenapa perlu agen?

Halaman web **tidak diizinkan** memilih printer sendiri (aturan keamanan semua browser) — pilihan
printer hanya bisa lewat dialog cetak milik sistem. Agen kecil ini menjadi perantara: aplikasi
mengirim tiket ke agen, lalu agen mencetaknya ke printer yang **Anda tentukan di berkas config**.
Karena printer ditentukan oleh agen (bukan printer default Windows), aplikasi lain di komputer yang
sama tetap memakai printer default sistemnya.

## Yang dibutuhkan

| Kebutuhan | Keterangan |
| --- | --- |
| Komputer apotek (Windows) | Komputer yang dipakai petugas mencetak tiket |
| PHP CLI | Minimal PHP 7.4 — sama seperti yang dipakai agen SIMRS bila sudah ada |
| Printer thermal | Sudah terpasang & tercetak baik dari Windows |

## Pemasangan (5 langkah)

1. Salin folder `agen-cetak` ke komputer apotek (mis. `C:\agen-cetak`).
2. Salin `config.contoh.php` menjadi **`config.php`**.
3. Isi `config.php`:
   - `printer` → **nama printer thermal persis seperti di Windows**
     (lihat *Printer & scanner* di Windows, atau tekan **Ambil Daftar Printer** di aplikasi).
   - `token` → salin dari aplikasi: **Pengaturan → Printer → Agen Cetak → Token**.
4. Klik dua kali **`jalankan-agen-cetak.bat`** (biarkan jendelanya terbuka).
5. Di aplikasi: **Pengaturan → Printer → Agen Cetak** → tekan **Uji Koneksi Agen**, lalu
   **Tes Cetak** (kertas uji harus keluar dari printer thermal), lalu centang
   **"Cetak tiket lewat agen"** dan simpan.

> **Penting:** **Uji Koneksi Agen tidak berhubungan dengan printer.** Yang diperiksa hanya apakah
> agen hidup di `127.0.0.1:17890`. Printer baru dipakai saat **Tes Cetak**. Jadi bila muncul
> "tidak dapat menghubungi agen", penyebabnya ada di sisi agen/`config.php` — **bukan** karena
> printer belum terhubung ke komputer.

## Mode cetak

| Mode | Isi tiket | Catatan |
| --- | --- | --- |
| `gambar` (bawaan) | Gambar tiket lengkap **termasuk QR** untuk lacak obat | Dicetak lewat `PrintTo` (pakai aplikasi gambar bawaan Windows) |
| `teks` | Teks polos, **tanpa QR** | Paling kompatibel untuk semua driver; alamat tautan lacak tetap dicetak |

Bila mode `gambar` hasilnya tidak rapi di printer Anda, ubah `'mode' => 'teks'` di `config.php`.

## Uji coba tanpa printer

Isi `'kering' => true` di `config.php`. Agen tidak akan mengirim apa pun ke printer — tiket hanya
disimpan sebagai berkas di folder `keluaran/`, sehingga bisa diperiksa lebih dulu. Ubah kembali ke
`false` setelah semuanya benar.

## Perintah yang tersedia

| Perintah | Fungsi |
| --- | --- |
| `jalankan-agen-cetak.bat` | Menjalankan agen (Windows, klik dua kali) |
| `php -S 127.0.0.1:17890 agen-cetak.php` | Menjalankan agen secara manual |
| `http://127.0.0.1:17890/status` | Melihat daftar printer & pengaturan agen (di browser) |
| `http://127.0.0.1:17890/uji` | Mencetak halaman uji |

## Bila ada masalah

| Gejala | Penanganan |
| --- | --- |
| Aplikasi bilang "Agen cetak tidak merespons" | Agen belum jalan, atau alamat agen di aplikasi berbeda. Jalankan `jalankan-agen-cetak.bat` dan tekan "Uji Koneksi Agen". |
| Jendela agen menampilkan `PHP Parse error: syntax error, unexpected ... expecting "]" in config.php on line 39` | **config.php salah ketik** (bukan masalah printer). Lihat bagian *config.php salah ketik* di bawah. |
| Aplikasi bilang "Agen SUDAH berjalan, tetapi config.php bermasalah" | Agen hidup tetapi tidak bisa membaca config.php. Pesan di aplikasi memuat baris yang salah — perbaiki seperti bagian *config.php salah ketik*. |
| "Token tidak cocok" | Token di `config.php` berbeda dengan yang di aplikasi. Salin ulang, lalu jalankan ulang agen. |
| "Nama printer belum diisi" | Isi `printer` di `config.php` dengan nama printer yang **persis sama** (perhatikan huruf besar/kecil & spasi). |
| Tiket keluar dari printer yang salah | Nama printer di `config.php` salah/tertukar. Tekan **Ambil Daftar Printer** di aplikasi untuk melihat nama yang benar. |
| Hasil cetak gambar terpotong / kekecilan | Ubah `'mode' => 'teks'`, atau atur ukuran kertas printer menjadi 80 mm tanpa margin di Windows. |
| Ingin tahu apa yang dicetak | Isi `'kering' => true`, lalu periksa berkas di folder `keluaran/`. Semua aktivitas juga dicatat di `agen-cetak.log`. |

## config.php salah ketik (Parse error)

Printer **tidak perlu terhubung** untuk urusan ini: kalau `config.php` salah ketik, PHP menolak membaca
berkas itu, agen tidak pernah hidup, dan aplikasi hanya bisa berkata "tidak dapat menghubungi agen".

Contoh pesan di jendela agen:

```
PHP Parse error:  syntax error, unexpected single-quoted string "folder_keluar", expecting "]" in
C:\agen-cetak\config.php on line 39
```

Artinya: di **baris tepat sebelum baris yang disebut** (yaitu akhir baris "false" di atasnya),
**tanda koma hilang**. Nomor barisnya berbeda-beda sesuai berkas Bapak/Ibu — yang penting adalah
aturan berikut: setiap baris di dalam `[ ... ]` wajib diakhiri koma.

```php
    'kering'        => false,          // ← koma ini yang sering tertinggal
    'folder_keluar' => __DIR__ . '/keluaran',
```

Yang dilakukan sekarang bila hal ini terjadi:

1. `jalankan-agen-cetak.bat` memeriksa dulu tulisan `config.php` (`php -l`). Bila ada yang salah,
   pesannya ditampilkan, Notepad dibuka pada berkas itu, dan agen tidak dijalankan
   (jadi tidak perlu menebak-nebak lagi).
2. Bila agen dijalankan manual dan `config.php` masih salah ketik, agen **tetap hidup** tetapi setiap
   permintaan dijawab dengan penjelasan yang jelas — halaman **Pengaturan → Printer** menampilkan
   "config.php bermasalah" beserta nomor barisnya, bukan lagi "tidak dapat menghubungi agen".

Cara paling aman kalau ragu: **salin ulang `config.contoh.php` menjadi `config.php`** (timpa yang lama),
lalu isi hanya `'printer'` dan `'token'` — jangan mengubah tanda koma, tanda kutip, atau kurung lainnya.

## Catatan keamanan

- Agen hanya mendengarkan di **127.0.0.1** (hanya komputer itu sendiri), bukan dari jaringan.
- Token mencegah situs lain ikut mencetak lewat agen ini — jangan dibagikan.
- Berkas yang dicetak disimpan di folder `keluaran/`; boleh dibersihkan kapan saja.
